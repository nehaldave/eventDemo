module.exports = {
  tableName: 'user_master',
  attributes: {
    name: {
      type: 'String'
    },
    email: {
      type: "String",
      required: true,
      unique: true

    },
    password: {
      type: "String"
    },
    role: {
      type: "String"
    },
    uid: {
      type: "Number",
      required: true,
      unique: true
    }
  }
}
