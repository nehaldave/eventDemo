module.exports = {
  tableName: 'event_details',
  attributes: {
    name: {
      type: 'String'
    },
    description: {
      type: "String"
    },
    place: {
      type: "String"
    },
    startDate: {
      type: 'String',
      columnType: 'datetime'
    },
    endDate: {
      type: 'String',
      columnType: 'datetime'
    },
    interested: {
      type: "json",
      columnType: 'array'
    },
    created_by: {
      type: "Number",
      required: true
    },
    eventid: {
      type: "Number",
      required: true,
      unique: true

    }
  }
}
