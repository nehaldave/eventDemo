require('../models/Event')
require('../models/User')
async function getEvents(userData, callback) {
  sails.mongodb.collection('user_master').aggregate([{
    $match: {
      uid: parseInt(userData.usercode),
      role: 'client'
    }
  }]).toArray((error, response) => {
    if (error) {
      return callback(error)
    } else {
      if (response.length > 0) {
        sails.mongodb.collection('event_details').find({
          status: 'Activate'
        }).toArray((error, res) => {
          if (error) {
            return callback(error)
          } else {
            if (res.length > 0) {
              return callback(res)
            } else {
              return callback('There is no Active Event ')
            }
          }
        })
      }
    }
  })
}

async function addEvent(payload, eventCB) {
  let res = await sails.mongodb.collection('event_details').find().sort({
    eventid: -1
  }).limit(1).toArray()
  let eventID
  if (res.length == 0) {
    eventID = 0
  } else {
    eventID = res[0].eventid
  }
  sails.mongodb.collection('event_details').insert({
    name: payload.name,
    description: payload.description,
    place: payload.place,
    startDate: payload.startDate,
    endDate: payload.endDate,
    status: "Activate",
    eventid: eventID + 1,
    created_by: payload.created_by
  }, (error, response) => {
    if (error) {
      return eventCB(error)
    } else {
      return eventCB(null, 'Event added Succesfully')
    }
  })

}

module.exports = {
  getEvents: getEvents,
  addEvent: addEvent
}
