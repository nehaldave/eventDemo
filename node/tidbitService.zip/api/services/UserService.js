require('../models/User')
async function loginData(userData, callback) {

  sails.mongodb.collection('user_master').find({
    email: userData.email
  }).toArray((error, response) => {
    if (error) {
      return callback(error)
    } else {
      if (response.length > 0) {
        if (response[0].password === userData.password) {
          let responseJson = {}
          responseJson['userCode'] = response[0].uid
          return callback(responseJson)
        }
        return callback('Email & Password does not match')
      }
      return callback(' User not Registerd')
    }
  })
}

async function register(payload, registerCB) {
  let res = await sails.mongodb.collection('user_master').find().sort({
    uid: -1
  }).limit(1).toArray()
  let userId
  if (res.length == 0) {
    userId = 0
  } else {
    userId = res[0].uid
  }
  sails.mongodb.collection('user_master').insert({
    name: payload.name,
    email: payload.email,
    password: payload.password,
    role: payload.role,
    uid: userId + 1
  }, (error, response) => {
    if (error) {
      return registerCB(error)
    } else {
      return registerCB(null, response)
    }
  })

}

module.exports = {
  loginData: loginData,
  register: register
}
