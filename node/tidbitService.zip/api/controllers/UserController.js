module.exports = {
  login: login,
  register: register
}

function login(req, res) {
  UserService.loginData(req.body, (error, response) => {
    if (error) {
      res.send(error)
    } else {
      console.log('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
      res.send(response)
    }
  })
}

function register(req, res) {
  UserService.register(req.body, (error, response) => {
    if (error) {
      res.send(error)
    } else {
      res.send('Registerd Succesfully')
    }
  })
}
