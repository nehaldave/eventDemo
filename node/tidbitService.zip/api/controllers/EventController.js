module.exports = {
  addEvent: addEvent,
  getEvents: getEvents
}

function addEvent(req, res) {
  EventService.addEvent(req.body, (error, response) => {
    if (error) {
      res.send(error)
    } else {
      console.log('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
      res.send(response)
    }
  })
}

function getEvents(req, res) {
  EventService.getEvents(req.params, (error, response) => {
    if (error) {
      res.send(error)
    } else {
      console.log('-------------------------Response-------------------------------', response);
      res.send(response)
    }
  })
}
